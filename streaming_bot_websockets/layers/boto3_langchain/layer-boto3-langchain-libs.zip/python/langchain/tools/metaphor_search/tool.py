from langchain_community.tools.metaphor_search.tool import MetaphorSearchResults

__all__ = ["MetaphorSearchResults"]
