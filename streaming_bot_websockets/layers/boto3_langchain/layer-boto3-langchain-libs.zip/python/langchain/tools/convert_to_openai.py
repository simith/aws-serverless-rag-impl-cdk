from langchain_community.tools.convert_to_openai import format_tool_to_openai_function

# For backwards compatibility
__all__ = ["format_tool_to_openai_function"]
