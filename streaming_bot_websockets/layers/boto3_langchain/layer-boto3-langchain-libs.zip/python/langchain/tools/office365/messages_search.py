from langchain_community.tools.office365.messages_search import (
    O365SearchEmails,
    SearchEmailsInput,
)

__all__ = ["SearchEmailsInput", "O365SearchEmails"]
