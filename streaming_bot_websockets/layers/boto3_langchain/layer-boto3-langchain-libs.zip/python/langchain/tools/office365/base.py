from langchain_community.tools.office365.base import O365BaseTool

__all__ = ["O365BaseTool"]
