from langchain_community.tools.graphql.tool import BaseGraphQLTool

__all__ = ["BaseGraphQLTool"]
