from langchain_community.tools.edenai.audio_text_to_speech import EdenAiTextToSpeechTool

__all__ = ["EdenAiTextToSpeechTool"]
