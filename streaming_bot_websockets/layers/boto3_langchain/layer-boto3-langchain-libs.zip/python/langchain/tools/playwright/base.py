from langchain_community.tools.playwright.base import (
    BaseBrowserTool,
)

__all__ = ["BaseBrowserTool"]
