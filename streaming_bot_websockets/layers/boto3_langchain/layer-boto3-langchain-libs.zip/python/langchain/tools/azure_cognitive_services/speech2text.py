from langchain_community.tools.azure_cognitive_services.speech2text import (
    AzureCogsSpeech2TextTool,
)

__all__ = ["AzureCogsSpeech2TextTool"]
