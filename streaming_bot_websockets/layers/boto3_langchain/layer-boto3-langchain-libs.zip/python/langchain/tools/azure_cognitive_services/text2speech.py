from langchain_community.tools.azure_cognitive_services.text2speech import (
    AzureCogsText2SpeechTool,
)

__all__ = ["AzureCogsText2SpeechTool"]
