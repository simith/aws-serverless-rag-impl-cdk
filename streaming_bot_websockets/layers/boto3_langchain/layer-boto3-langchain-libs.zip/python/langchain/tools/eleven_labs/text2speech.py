from langchain_community.tools.eleven_labs.text2speech import (
    ElevenLabsText2SpeechTool,
)

__all__ = ["ElevenLabsText2SpeechTool"]
