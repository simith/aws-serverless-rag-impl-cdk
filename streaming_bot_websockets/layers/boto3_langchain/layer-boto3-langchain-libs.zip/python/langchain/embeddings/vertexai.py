from langchain_community.embeddings.vertexai import VertexAIEmbeddings

__all__ = ["VertexAIEmbeddings"]
