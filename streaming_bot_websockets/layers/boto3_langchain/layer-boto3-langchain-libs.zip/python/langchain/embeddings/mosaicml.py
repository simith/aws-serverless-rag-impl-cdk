from langchain_community.embeddings.mosaicml import MosaicMLInstructorEmbeddings

__all__ = ["MosaicMLInstructorEmbeddings"]
