from langchain_community.embeddings.sentence_transformer import (
    SentenceTransformerEmbeddings,
)

__all__ = ["SentenceTransformerEmbeddings"]
