from langchain_community.embeddings.mlflow_gateway import (
    MlflowAIGatewayEmbeddings,
)

__all__ = ["MlflowAIGatewayEmbeddings"]
