from langchain_community.embeddings.gpt4all import GPT4AllEmbeddings

__all__ = ["GPT4AllEmbeddings"]
