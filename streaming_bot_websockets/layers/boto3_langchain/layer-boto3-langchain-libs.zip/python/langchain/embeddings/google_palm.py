from langchain_community.embeddings.google_palm import (
    GooglePalmEmbeddings,
)

__all__ = ["GooglePalmEmbeddings"]
