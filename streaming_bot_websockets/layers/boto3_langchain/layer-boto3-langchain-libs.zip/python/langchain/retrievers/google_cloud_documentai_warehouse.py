from langchain_community.retrievers.google_cloud_documentai_warehouse import (
    GoogleDocumentAIWarehouseRetriever,
)

__all__ = ["GoogleDocumentAIWarehouseRetriever"]
