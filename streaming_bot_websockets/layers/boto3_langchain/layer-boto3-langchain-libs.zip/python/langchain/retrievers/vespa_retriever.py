from langchain_community.retrievers.vespa_retriever import VespaRetriever

__all__ = ["VespaRetriever"]
