from langchain_community.retrievers.wikipedia import WikipediaRetriever

__all__ = ["WikipediaRetriever"]
